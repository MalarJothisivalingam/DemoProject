package com.capgemini.fms.bean;

public class Faculty {
	private int facultyId;
	private String skillset;

	public Faculty() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Faculty(int facultyId, String skillset) {
		super();
		this.facultyId = facultyId;
		this.skillset = skillset;
	}

	public int getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(int facultyId) {
		this.facultyId = facultyId;
	}

	public String getSkillset() {
		return skillset;
	}

	public void setSkillset(String skillset) {
		this.skillset = skillset;
	}

	@Override
	public String toString() {
		return "Faculty [facultyId=" + facultyId + ", skillset=" + skillset
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + facultyId;
		result = prime * result
				+ ((skillset == null) ? 0 : skillset.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Faculty other = (Faculty) obj;
		if (facultyId != other.facultyId)
			return false;
		if (skillset == null) {
			if (other.skillset != null)
				return false;
		} else if (!skillset.equals(other.skillset))
			return false;
		return true;
	}

}
