package com.capgemini.fms.queries;

public interface IQueryMapper {
String GetTrainingList="SELECT a.Training_code,a.Course_Ids,a.FacultyId,b.Course_Name from TRAINING_PROGRAM a,COURSE_MASTER b  WHERE  b.Course_Ids=a.Course_Ids AND Training_code=?";
String  GetTrainingId="SELECT Training_code from TRAINING_ENROLLMENT WHERE Participant_Id=?";
String GetTrainingDetails="SELECT Training_code,Course_Ids,FacultyId,StartDate,EndDate from TRAINING_PROGRAM  WHERE  Training_code=?";
String AddFeedback="INSERT INTO FEEDBACK_MASTER VALUES(?,?,?,?,?,?,?,?,?)";
}
