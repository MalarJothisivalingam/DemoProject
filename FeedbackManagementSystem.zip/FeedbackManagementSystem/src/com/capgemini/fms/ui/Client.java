package com.capgemini.fms.ui;


import com.capgemini.fms.ui.AdminHelper;

public class Client {
	
	public static void main(String[] args) {
		new AdminHelper();   //ui for the login and admin home
	}
	

}
