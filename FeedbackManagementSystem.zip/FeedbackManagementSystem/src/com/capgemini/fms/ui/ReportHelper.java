package com.capgemini.fms.ui;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;

import com.capgemini.fms.bean.ReportBean;
import com.capgemini.fms.service.ReportService;
import com.capgemini.fms.service.ReportServiceImpl;

public class ReportHelper {
	ReportService service = new ReportServiceImpl();
	private BufferedReader reader = new BufferedReader(new InputStreamReader(
			System.in));
	public ReportHelper() {
		displayFeedBackMenu();
	}
	

	private void displayFeedBackMenu() {
		try {
			System.out.println("Select one:");
			System.out.println("1.Display training reports for the particular month");
			System.out.println("2.Display faculty wise reports for the particular month");
			System.out.println("3.Display training defaulters for the particular month");
			System.out.println("0. Back");
			int choice = Integer.parseInt(reader.readLine());
			switch (choice) {
			case 1:
				displayReportbyMonth();
				break;
			case 2:
				displayReportByFaculty();
			case 3:
				displayDefaulterReport();
			case 0:
				 new AdminHelper();
			default:
				System.err.println("Invalid Choice : Enter again");
				break;
			}
		} catch (NumberFormatException e) {
			System.err.println("Cannot enter characters only numbers: Please try again");
			displayFeedBackMenu();
		} catch (IOException e) {
			System.err.println("Something went wrong : Please try again");
			displayFeedBackMenu();
		}
	}

	private void displayReportByFaculty() {
		try {
			System.out.println("Enter faculty Id");
			int facultyId = Integer.parseInt(reader.readLine());
			displayMonths();
			System.out.println("enter month");
			int month = Integer.parseInt(reader.readLine());
			ArrayList<ReportBean> reports = service.getFacultyReport(facultyId,
					month);
			System.out.println("Date\t\tTraining Code\t\t\t\tFeedback Scores");
			System.out.print("\t\t\t\t");
			System.out
					.println("Pres & Comm\tClarify Dbts\tTime Management\tHandOut\tHW/SW Network");
			for (ReportBean report : reports) {
				System.out.println(report.getDate() + "\t\t"
						+ report.getTrainingCode() + "\t\t"
						+ report.getFbPrsComm() + "\t\t"
						+ report.getFbClrfyDbts() + "\t\t" + report.getFbTM()
						+ "\t" + report.getFbHndOut() + "\t\t"
						+ report.getFbHwSwNtwrk());
			}
			System.out.println("Enter any key to go back..");
			String dummy = reader.readLine();
			displayFeedBackMenu();
		} catch (NumberFormatException e) {
			System.err
					.println("Cannot enter characters only numbers: Please try again");
			displayFeedBackMenu();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayFeedBackMenu();
		}

	}

	private void displayReportbyMonth() {
		try {
			displayMonths();
			System.out.println("Enter Month");
			int month = Integer.parseInt(reader.readLine());
			ArrayList<ReportBean> reports = service.getAllTrainingReport(month);
			System.out
					.println("Date\t\tTraining Code\t\tFaculty\t\t\t\tFeedback Scores");
			System.out.print("\t\t\t\t\t\t");
			System.out
					.println("Pres & Comm\tClarify Dbts\tTime Management\tHandOut\tHW/SW Network");
			for (ReportBean report : reports) {
				System.out.println(report.getDate() + "\t\t"
						+ report.getTrainingCode() + "\t\t"
						+ report.getFacultyName() + "\t\t"
						+ report.getFbPrsComm() + "\t\t"
						+ report.getFbClrfyDbts() + "\t\t" + report.getFbTM()
						+ "\t" + report.getFbHndOut() + "\t\t"
						+ report.getFbHwSwNtwrk());
			}
			System.out.println("Enter any key to go back..");
			String dummy = reader.readLine();
			displayFeedBackMenu();
		} 
		catch (NumberFormatException e) {
			System.err.println("Cannot enter characters only numbers: Please try again");
			displayFeedBackMenu();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayFeedBackMenu();
		}
	}

	private void displayDefaulterReport() {
		try {
			displayMonths();
			System.out.println("Enter Month");
			int month = Integer.parseInt(reader.readLine());
			ArrayList<ReportBean> reports = service.getDefaulterReport(month);
			if(reports.isEmpty())
			{
				System.out.println("No Defaulters for the Selected Month");
			}
			else
			{
			System.out
					.println("Date\t\tTraining Code\tParticipant Name\tFaculty\t\t\t\tFeedback Scores");
			System.out.print("\t\t\t\t\t\t\t\t\t");
			System.out
					.println("Pres & Comm\tClarify Dbts\tTime Management\tHandOut\tHW/SW Network");
			for (ReportBean report : reports) {
				displayValues(report);
			}
			}
			System.out.println("Enter any key to go back..");
			String dummy = reader.readLine();
			displayFeedBackMenu();
		} 
		catch (NumberFormatException e) {
			System.err.println("Cannot enter characters only numbers: Please try again");
			displayFeedBackMenu();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayFeedBackMenu();
		}

	}

	public void displayValues(ReportBean report) {
		int[] valuesArr = new int[5];
		valuesArr[0] = report.getFbPrsComm();
		valuesArr[1] = report.getFbClrfyDbts();
		valuesArr[2] = report.getFbTM();
		valuesArr[3] = report.getFbHndOut();
		valuesArr[4] = report.getFbHwSwNtwrk();
		System.out.print(report.getDate() + "\t\t" + report.getTrainingCode()
				+ "\t\t" + report.getParticipantName() + "\t\t"
				+ report.getFacultyName() + "\t\t");
		for (int index = 0; index < valuesArr.length; index++){
			if (valuesArr[index] == 0)
				System.out.print("X\t\t");
			else
				System.out.print(valuesArr[index] + "\t\t");
		}
		System.out.println();
		System.out.println("Value X represents the feedback is not yet provided");
	}
	
	public void displayMonths() {
		System.out.println("1.  January");
		System.out.println("2.  February");
		System.out.println("3.  March");
		System.out.println("4.  April");
		System.out.println("5.  May");
		System.out.println("6.  June");
		System.out.println("7.  July");
		System.out.println("8.  August");
		System.out.println("9.  September");
		System.out.println("10. October");
		System.out.println("11. November");
		System.out.println("12. December");
	}
}
